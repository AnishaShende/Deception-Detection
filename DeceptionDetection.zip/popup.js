document.addEventListener("DOMContentLoaded", function () {
  // chrome.runtime.onMessage.addListener(function (
  //   message,
  //   sender,
  //   sendResponse
  // ) {
  //   if (message.action === "classificationResult") {
  //     const predictions = message.classification;
  //     console.log("predictions: (inside popup.js)", predictions);
  //     highlightDeceptiveTexts(predictions);
  //   }
  // });
  detectPhishing();
  document
    .getElementById("detectButton")
    .addEventListener("click", async function () {
      // Show loading animation
      document.getElementById("loading").style.display = "block";

      // Send message to content script to get texts and make prediction
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "detectTexts" });
      });
      // // Send message to background script to get texts
      // chrome.runtime.sendMessage({ action: "detectTexts" });
    });
});

// Listen for classification results from content script
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  // console.log("back to popup.js: Message received:", message);
  if (message.action === "classificationResultForPopup") {
    document.getElementById("loading").style.display = "none";
    document.getElementById("detectButton").style.display = "none";

    // const predictions = message.classification;
    // console.log("predictions: (inside popup.js)", predictions);
    // displayResults(predictions);

    // Hide the loading animation
  }
});
function detectPhishing() {
  showLoading(true);

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var url = tabs[0].url;
    var urlObj = new URL(tabs[0].url);
    var url = urlObj.hostname;

    updateWebsite(url);

    makePrediction(url)
      .then((isPhishing) => {
        updateButton(isPhishing);
        updateWebsiteDetails(isPhishing);
        setTimeout(() => {
          updateButton(isPhishing);
        }, 2000);
      })
      .catch((error) => {
        console.error("Error making prediction:", error);
      })
      .finally(() => {
        showLoading(false);
      });
  });
}
function updateButton(isPhishing) {
  var button = document.getElementById("detectButton");

  button.style.backgroundColor = "black";
  button.style.color = "white";

  if (isPhishing) {
    // button.innerText = "Scam";
    // button.style.backgroundColor = "red";
    document.querySelector(".wrapper").style.backgroundColor =
      "rgba(255, 0, 0, 0.5)";
    detectButton.style.display = "block";
  } else {
    // button.innerText = "Genuine!";
    // button.style.backgroundColor = "green";
    document.querySelector(".wrapper").style.backgroundColor =
      "rgba(0, 255, 0, 0.5)";
    detectButton.style.display = "none";
  }
}
function updateWebsite(url) {
  var websiteName = document.getElementById("website");

  websiteName.innerText = `Website: ${url}`;
}

function updateWebsiteDetails(isPhishing) {
  var websiteName = document.getElementById("website");
  var accuracyText = document.getElementById("accuracy-text");
  var detectButton = document.getElementById("detectButton");

  if (isPhishing) {
    updateButton(isPhishing);
    // document.querySelector(".wrapper").style.backgroundColor =
    //   "rgba(255, 0, 0, 0.5)";
    // detectButton.style.display = "block";
  } else {
    updateButton(isPhishing);
    // document.querySelector(".wrapper").style.backgroundColor =
    //   "rgba(0, 255, 0, 0.5)";
    // detectButton.style.display = "none";
  }
}
async function makePrediction(url) {
  try {
    const apiUrl = "http://127.0.0.1:5000/check-url";
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ url: url }),
    });
    // console.log(response);
    if (response.ok) {
      try {
        const data = await response.json();
        // console.log(data);
        if ("prediction" in data) {
          const predictionLikelihood = data["prediction"];
          updateAccuracyText(predictionLikelihood);
          return parseFloat(predictionLikelihood) >= 40;
        } else {
          console.error("Invalid response format:", data);
          return false;
        }
      } catch (error) {
        console.error("Invalid JSON in response:", error);
        return false;
      }
    } else {
      console.error("Request failed with status:", response.status);
      return false;
    }
  } catch (error) {
    console.error("Error making prediction:", error);
    return false;
  }
}

function updateAccuracyText(likelihood) {
  var accuracyText = document.getElementById("accuracy-text");
  document.getElementById("loadingText").style.display = "none";
  accuracyText.innerText = `Likelihood: ${likelihood}`;
}
function showLoading(isLoading) {
  var loadingDiv = document.getElementById("loading");
  var detectButton = document.getElementById("detectButton");

  if (isLoading) {
    loadingDiv.style.display = "block";

    detectButton.disabled = true;
  } else {
    loadingDiv.style.display = "none";

    detectButton.disabled = false;
  }
}
// function displayResults(predictions) {
//   // TODO: Display the prediction results in the popup UI
// }

// function highlightDeceptiveTexts(predictions) {
//   predictions.forEach((prediction) => {
//     if (prediction.prediction[0].label === "Dark_Pattern") {
//       const text = prediction.text;
//       console.log("Highlighting dark pattern text:", text);

//       // const elements = document.querySelectorAll("*");
//       // elements.forEach((element) => {
//       //   if (element.innerText.includes(text)) {
//       //     element.style.backgroundColor = "yellow";
//       //   }
//       // });

//       // Find all elements containing the deceptive text and highlight them
//       document.querySelectorAll("*").forEach((element) => {
//         if (element.innerText.includes(text)) {
//           element.style.backgroundColor = "yellow";
//         }
//       });
//     }
//   });
// // Hide the loading animation
// document.getElementById("loading").style.display = "none";
// }
