// console.log("Content.js loaded");

// function getTextsFromPage() {
//   const texts = Array.from(
//     document.querySelectorAll("p, h1, h2, h3, h4, h5, h6, a")
//   )
//     .map((element) => (element.innerText ? element.innerText.trim() : ""))
//     .filter((text) => text.length > 0);
//   console.log("getTextsFromPage:", texts);
//   return texts;
// }
function getTextsFromPage() {
  const texts = Array.from(document.querySelectorAll("*"))
    .map((element) => (element.innerText ? element.innerText.trim() : ""))
    // .map((element) => element.innerText.trim())
    .filter((text) => text.length > 0);
  console.log("getTextsFromPage:", texts);
  return texts;
}

// Get texts from the page and send them to the background script for classification

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "detectTexts") {
    console.log("detectTexts action performed in popup.js");
    // TODO: Perform the text detection and prediction logic here
    const texts = getTextsFromPage();
    chrome.runtime.sendMessage({ action: "classifyTexts", texts });
  }
});

// Listen for classification results from background script
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  console.log("Message received:", message);
  if (message.action === "classificationResult") {
    const classification = message.classification;
    console.log("classification: ", classification);
    highlightTexts(classification);
  }
});

function highlightTexts(classifications) {
  classifications.forEach((classification) => {
    if (classification.prediction[0].label === "Dark_Pattern") {
      const regex = new RegExp(classification.text, "gi");
      document.querySelectorAll("*").forEach((element) => {
        const html = element.innerHTML;
        const replacedHtml = html.replace(
          regex,
          '<span style="background-color: yellow;">$&</span>'
        );
        if (html !== replacedHtml) {
          element.innerHTML = replacedHtml;
        }
      });
    }
  });
}
// function highlightDeceptiveTexts(predictions) {
//   predictions.forEach((prediction) => {
//     if (prediction.prediction[0].label === "Dark_Pattern") {
//       const text = prediction.text;
//       console.log("Highlighting dark pattern text:", text);

//       // Find all elements containing the deceptive text and highlight them
//       document.querySelectorAll("*").forEach((element) => {
//         // if (element.innerText.includes(text)) {
//         //   element.style.backgroundColor = "yellow";
//         // }
//         const html = element.innerHTML;
//         const replacedHtml = html.replace(
//           '<span style="background-color: yellow;">$&</span>'
//         );
//         if (html !== replacedHtml) {
//           element.innerHTML = replacedHtml;
//         }
//       });
//     }
//   });
// }
