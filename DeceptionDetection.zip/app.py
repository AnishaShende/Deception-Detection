from huggingface_hub import hf_hub_download
from flask import Flask, request, jsonify
from transformers import pipeline
from flask_cors import CORS
import onnxruntime
import numpy as np
import requests
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the model
model = "Vinzzz03/distilroberta-dark-pattern"
classifier = pipeline("text-classification", model=model)
REPO_ID = "pirocheto/phishing-url-detection"
FILENAME = "model.onnx"
model_path = hf_hub_download(repo_id=REPO_ID, filename=FILENAME)
sess = onnxruntime.InferenceSession(model_path, providers=["CPUExecutionProvider"])

# Function to classify texts individually
def classify_texts(texts):
    results = []
    for text in texts:
        # Classify each text individually
        prediction = classifier(text, max_length=512)
        results.append(prediction)
    return results

@app.route('/check-texts', methods=['POST'])
def check_texts():
    data = request.get_json()
    texts = data.get('texts')
    if texts is None:
        return jsonify({'error': 'No texts field provided.'}), 400
    
    # Remove duplicate texts
    unique_texts = list(set(texts))

    # Classify texts in chunks
    predictions = classify_texts(unique_texts)
    # predictions = classify_texts_in_chunks(texts)
    print("Server is running")
    print("Sending predictions (inside app.py): ", predictions)
    # Return predictions along with original text
    classified_texts = [{"text": text, "prediction": prediction} for text, prediction in zip(texts, predictions)]
    return jsonify(classified_texts)
    # return jsonify(predictions)

@app.route('/proxy', methods=['POST'])
def proxy():
    data = request.get_json()
    url = data.get('url')
    payload = data.get('payload')
    print("inside proxy server")
    if url is None:
        return jsonify({'error': 'No URL provided.'}), 400

    response = requests.post(url, json=payload)
    print("Response inside proxy:", response)
    return jsonify(response.json())

@app.route("/check-url", methods=["POST"])
def check_url():
    try:
        url = request.json.get("url")
        print("Received URL:", url)
        if not url:
            return "No URL provided in the request.", 400

       
        result = sess.run(None, {"inputs": np.array([url], dtype="str")})[1]

        
        return jsonify({"prediction": f"{result[0][1] * 100:.2f} %"})

    except Exception as e:
        print("Error:", e)
        return "Internal server error.", 500

if __name__ == '__main__':
    app.run(debug=True)